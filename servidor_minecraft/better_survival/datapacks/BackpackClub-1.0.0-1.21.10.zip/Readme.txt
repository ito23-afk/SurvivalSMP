-------------------------------------------
BACKPACK CLUB
by Aegis Architectum

Purely server-side or singleplayer.
Equipable, dyeable, upgradable, craftable, enchantable, placeable, repairable, protective backpacks.
-------------------------------------------

Requirements (server side / singleplayer):
	- Polymer https://modrinth.com/mod/polymer
	- Filament https://modrinth.com/mod/filament
	- Enable "AutoHost" in Polymer config: https://polymer.pb4.eu/latest/user/resource-pack-hosting/
	
Recommendations:
	- Simple Datapacks https://modrinth.com/mod/simple-datapacks

Features:
	- Craftable, tiered backpacks: each new tier has more space and protection.
	- Wearable in chest slot. Every backpack tier has own custom model.
	- Each tier has same protection as corresponding chestplate - and even higher!
	- Dragon backpack acts like Elytra as well.
	- When upgraded to a higher tier in Smithing Table, your new backpack keeps all properties, items and enchantments.
	- Can be placed on ground and interacted with as a block: works with hoppers, pipes, droppers etc.
	- Can be opened from hand.
	- Can be dyed.
	- Can be enchanted.
	- Can be repaired with corresponding material.
	- No overrides: should work with other mods and datapacks.
	
	- Adjusted for skin overlay layer offset.
    - Fully translatable.
    - Tagged as "minecraft:chest_armor", "backpackclub:backpacks" and "c:backpacks".
    - Separate creative tab.
    - Clean approach: no console errors.
    - Everything is data-driven.

Links:
	- Discord: https://discord.gg/fWW4Atmr69
	- Modrinth: https://modrinth.com/organization/aegis-architectum
	- CurseForge: https://www.curseforge.com/members/mjramon