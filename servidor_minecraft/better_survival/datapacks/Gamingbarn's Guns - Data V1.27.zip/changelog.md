## GBG V1.27

**Added Grenade Launcher**
- There's a brand-new gun in Gamingbarn's Guns, the Grenade Launcher
- It's much like the Milkor MGL from Modern Guns in terms of rough stats and function
- The gun is rather expensive to craft, and has very costly ammunition, only being edged out by the Bazooka and its rockets
- The Grenade Launcher uses the Grenade throwable as ammunition

**Updated Standard Gun Models**
- The models for the Pistol, Assault Rifle, Shotgun, and Sniper Rifle have been updated
- These updated models are inspired/copied from Modern Guns

**Resized Gun Models in Inventory**
- The models of the guns in the inventory have been resized to fit within the inventory square
- Larger guns no longer overflow into other slots, making other items harder to see

**Resized Gun Models on Ground**
- The gun models are now much smaller when dropped on the ground

**Updated Resource Pack Link**
- The resource pack verification popup has had the download link for the resource pack updated
- The link now shows all resource pack versions, instead of dp+rp versions

**Fixed Multiple Custom Data Components Breaking Ammo Items**
- If an ammo item had multiple data entries in its `custom_data` component, the ammo wouldn't be recognized by GBG
- Ammo items can now have anything in their `custom_data` component, so long as the ammo item tag is present at the root

**Fixed Minigun Item Frame Model**
- The Minigun model in the item frame was misshapen

**Adjusted Laser Weapon Zoom Models**
- The Laser Weapon zoom models now inherit the regular model
- This results in slightly adjusted first-person zoom model views

