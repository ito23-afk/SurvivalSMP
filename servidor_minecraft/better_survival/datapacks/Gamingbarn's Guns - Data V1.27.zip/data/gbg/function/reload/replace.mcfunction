# Simple replacement if the user reloaded a gun with no item in the offhand
item replace entity @s weapon.mainhand from entity @s weapon.offhand
item replace entity @s weapon.offhand with air
