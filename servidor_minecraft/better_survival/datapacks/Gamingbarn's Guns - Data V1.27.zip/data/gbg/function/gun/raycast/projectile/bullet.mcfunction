## Bullet Raycast
particle minecraft:ash ^ ^ ^ 0 0 0 0 1
scoreboard players add @s gbg.raycast_distance 1

# Slowing Project Down in Water
execute if block ~ ~ ~ #gbg:water run scoreboard players add @s gbg.raycast_distance 4
# Breaking Glass
execute if block ~ ~ ~ #gbg:glass run playsound block.glass.break block @a ~ ~ ~ 1 0.2
execute if block ~ ~ ~ #gbg:glass run particle block{block_state:"minecraft:glass"} ~ ~ ~ 0 0 0 0 20 normal
execute if block ~ ~ ~ #gbg:glass_pane run fill ~ ~ ~ ~ ~ ~ water replace #gbg:glass_pane[waterlogged=true]
execute if block ~ ~ ~ #gbg:glass run fill ~ ~ ~ ~ ~ ~ air replace #gbg:glass
# Whizzby Sound
execute if score @s gbg.raycast_distance matches 30.. unless block ~ ~ ~ #gbg:water if entity @a[distance=..3.5,tag=!gbg.heard_whizby] run playsound gbg:bullet_whizby player @a[distance=..3.5,tag=!gbg.heard_whizby] ~ ~ ~ 1 1
execute if score @s gbg.raycast_distance matches 30.. unless block ~ ~ ~ #gbg:water if entity @a[distance=..3.5,tag=!gbg.heard_whizby] run tag @a[distance=..3.5] add gbg.heard_whizby

## When Hit
#block
execute unless block ^ ^ ^ #gbg:raycast_bullet run function gbg:gun/raycast/hit_block
execute unless block ^ ^ ^ #gbg:raycast_bullet run return fail
#entity
execute if score @s gbg.raycast_distance matches 10.. positioned ~-0.15 ~-0.15 ~-0.15 as @e[limit=1,type=!#gbg:not_mob,tag=!gbg.gun_shooter,tag=!gbg.gun_hit,dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.85 ~0.85 ~0.85 positioned ~0.85 ~0.85 ~0.85 run function gbg:gun/raycast/hit_entity
execute if score @s gbg.raycast_distance matches 10.. positioned ~-0.15 ~-0.15 ~-0.15 as @e[limit=1,type=!#gbg:not_mob,tag=!gbg.gun_shooter,tag=!gbg.gun_hit,dx=0] positioned ~-0.7 ~-0.7 ~-0.7 if entity @s[dx=0] positioned ~0.85 ~0.85 ~0.85 positioned ~0.85 ~0.85 ~0.85 run return fail

# Calling Raycast Again
execute unless score @s gbg.raycast_distance >= gbg.range gbg.temp positioned ^ ^ ^0.2 rotated ~ ~ run function gbg:gun/raycast/projectile/bullet

# Reseting Raycast
execute if score @s gbg.raycast_distance >= gbg.range gbg.temp run function gbg:gun/raycast/reset
