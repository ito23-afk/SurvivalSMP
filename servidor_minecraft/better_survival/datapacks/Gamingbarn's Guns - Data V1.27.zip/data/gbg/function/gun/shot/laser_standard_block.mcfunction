# Executing at the ground where the projectile hit
execute as @e[type=item_frame,tag=land_mine,distance=..1,limit=1,sort=nearest] at @s run function gbg:equipment/land_mine/disarm
execute as @e[type=item_frame,tag=c4,distance=..80,limit=1,sort=nearest] at @s run function gbg:equipment/land_mine/disarm
