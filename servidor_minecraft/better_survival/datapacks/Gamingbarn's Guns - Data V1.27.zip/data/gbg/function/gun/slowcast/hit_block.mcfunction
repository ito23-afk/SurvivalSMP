# Figuring out the damage type of the gun
execute store result storage gbg:macro input.damage int 1 run scoreboard players get @s gbg.slowcast.damage
data modify storage gbg:macro input.gun_name set from entity @s CustomName

# Running correct damage function depending on gun damage type
scoreboard players operation marker_damage_type gbg.temp = @e[type=marker,tag=gbg.slowcast,sort=nearest,limit=1] gbg.slowcast.damage_type
execute if score marker_damage_type gbg.temp matches 4 run function gbg:gun/shot/laser_standard_block
execute if score marker_damage_type gbg.temp matches 5 run function gbg:gun/shot/laser_strong_block
execute if score marker_damage_type gbg.temp matches 8 positioned ^ ^ ^-0.2 run function gbg:gun/shot/explosion with storage gbg:macro input
execute if score marker_damage_type gbg.temp matches 9 positioned ^ ^ ^-0.2 run function gbg:gun/shot/safe_explosion with storage gbg:macro input
function #gbg:damage_type_block

# Reseting Slowcast
kill @s

