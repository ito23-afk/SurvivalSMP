playsound minecraft:block.fire.extinguish player @a ~ ~ ~ 1 0.9
particle explosion ~ ~ ~ 0 0 0 0.1 1 force
kill @s
