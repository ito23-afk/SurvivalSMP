# Player Looping Function
execute as @a at @s run function gbg:player_loop

# Turrets
execute as @e[type=item_frame,tag=placer] at @s align xyz positioned ~0.5 ~ ~0.5 run function gbg:turret/placer
execute as @e[type=pig,tag=turret] at @s run function gbg:turret/loop
execute as @e[type=armor_stand,tag=destroyed,scores={gbg.turret_despawn_time=0}] at @s run function gbg:turret/despawn

execute as @e[type=armor_stand,tag=auto,tag=!destroyed] at @s unless entity @e[type=pig,tag=turret,distance=..0.1,limit=1,sort=nearest] run function gbg:turret/auto/stages/destroyed
execute as @e[type=armor_stand,tag=sentry,tag=!destroyed] at @s unless entity @e[type=pig,tag=turret,distance=..0.1,limit=1,sort=nearest] run function gbg:turret/sentry/stages/destroyed
execute as @e[type=armor_stand,tag=perdition,tag=!destroyed] at @s unless entity @e[type=pig,tag=turret,distance=..0.1,limit=1,sort=nearest] run function gbg:turret/perdition/stages/destroyed
scoreboard players remove @e[scores={gbg.behind_cover=1..}] gbg.behind_cover 1
scoreboard players remove @e[type=armor_stand,tag=destroyed,scores={gbg.turret_despawn_time=1..}] gbg.turret_despawn_time 1

