#scheduling itself
schedule function gbg:misc/scoreboard_add 4s replace
scoreboard players set gbg gb.datapack_detect 1

#scoreboards
execute as @a unless score @s gbg.id matches 1.. run function gbg:misc/id_add
scoreboard players add @a gbg.cooldown 0
scoreboard players add @e[type=#gbg:monster_player] gbg.behind_cover 0

#checking if pack loaded properly
execute unless score are_guns_loaded config.gbg matches 1 unless function gbg:misc/guns_loaded_check run tellraw @a [{color:"red",text:"⚠",extra:[{bold:true,text:" WARNING "},"⚠"]},"\n",{color:"yellow",text:"You have added Gamingbarn's Guns to your world without fully restarting!"},"\n",{color:"yellow",text:"This means some guns will not load properly!"},"\n",{color:"gold",bold:true,text:"To fix this:"},"\n",{color:"yellow",text:"Singleplayer "},{color:"gray",text:"->"},{color:"red",text:" "},{color:"white",text:"Leave the world and rejoin"},"\n",{color:"yellow",text:"Multiplayer "},{color:"gray",text:"->"},{color:"red",text:" "},{color:"white",text:"Restart the server"},"\n",{color:"gray",italic:true,text:"If done successfully, this message will not appear upon rejoining."}]

#giving recipes
recipe give @a gbg:ammo/laser/15v_laser_battery
recipe give @a gbg:ammo/laser/15v_laser_battery_bundle
recipe give @a gbg:ammo/laser/15v_laser_battery_from_15v_laser_battery
recipe give @a gbg:ammo/laser/9v_laser_battery
recipe give @a gbg:ammo/standard/assault_rifle_magazine
recipe give @a gbg:ammo/standard/flamethrower_canister
recipe give @a gbg:ammo/standard/minigun_canister
recipe give @a gbg:ammo/standard/pistol_magazine
recipe give @a gbg:ammo/standard/rocket
recipe give @a gbg:ammo/standard/shotgun_shell
recipe give @a gbg:ammo/standard/sniper_rifle_magazine
recipe give @a gbg:equipment/c4
recipe give @a gbg:equipment/c4_remote
recipe give @a gbg:equipment/land_mine
recipe give @a gbg:gun/laser/assault_laser_rifle
recipe give @a gbg:gun/laser/laser_cannon
recipe give @a gbg:gun/laser/laser_pistol
recipe give @a gbg:gun/laser/laser_rifle
recipe give @a gbg:gun/standard/assault_rifle
recipe give @a gbg:gun/standard/bazooka
recipe give @a gbg:gun/standard/flamethrower
recipe give @a gbg:gun/standard/minigun
recipe give @a gbg:gun/standard/pistol
recipe give @a gbg:gun/standard/shotgun
recipe give @a gbg:gun/standard/sniper_rifle
recipe give @a gbg:gun/standard/grenade_launcher
recipe give @a gbg:gun/ray/ray_gun_blue
recipe give @a gbg:gun/ray/ray_gun_green
recipe give @a gbg:gun/ray/ray_gun_pink
recipe give @a gbg:gun/ray/ray_gun_yellow
recipe give @a gbg:gun/ray/ray_gun_red
recipe give @a gbg:medical/absorption_syringe
recipe give @a gbg:medical/adv_bandage
recipe give @a gbg:medical/antidote_syringe
recipe give @a gbg:medical/simple_bandage
recipe give @a gbg:medical/health_boost_syringe
recipe give @a gbg:medical/laser_shield_mk1
recipe give @a gbg:medical/laser_shield_mk2
recipe give @a gbg:medical/medkit
recipe give @a gbg:medical/regeneration_syringe
recipe give @a gbg:medical/resistance_syringe
recipe give @a gbg:medical/swiftness_syringe
recipe give @a gbg:medical/syringe
recipe give @a gbg:throwables/pipe_bomb
recipe give @a gbg:throwables/grenade
recipe give @a gbg:throwables/molotov_cocktail
recipe give @a gbg:throwables/chemical_grenade
recipe give @a gbg:throwables/smoke_grenade
recipe give @a gbg:turret/auto
recipe give @a gbg:turret/perdition
recipe give @a gbg:turret/sentry
