loot give @s loot gbg:items/gun/standard/pistol
return 1