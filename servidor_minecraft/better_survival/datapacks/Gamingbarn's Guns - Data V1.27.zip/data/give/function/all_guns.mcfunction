loot give @s loot gbg:items/gun/standard/pistol
loot give @s loot gbg:items/gun/standard/assault_rifle
loot give @s loot gbg:items/gun/standard/sniper_rifle
loot give @s loot gbg:items/gun/standard/shotgun
loot give @s loot gbg:items/gun/standard/bazooka
loot give @s loot gbg:items/gun/standard/minigun
loot give @s loot gbg:items/gun/standard/flamethrower
loot give @s loot gbg:items/gun/standard/grenade_launcher

loot give @s loot gbg:items/gun/laser/laser_pistol
loot give @s loot gbg:items/gun/laser/laser_rifle
loot give @s loot gbg:items/gun/laser/assault_laser_rifle
loot give @s loot gbg:items/gun/laser/laser_cannon

loot give @s loot gbg:items/gun/ray/ray_gun
