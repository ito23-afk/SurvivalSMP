loot give @s loot gbg:items/gun/standard/sniper_rifle
