## Runs every tick
execute as @a unless score @s mp.settings matches 0 run function mp_utils:settings/nav
