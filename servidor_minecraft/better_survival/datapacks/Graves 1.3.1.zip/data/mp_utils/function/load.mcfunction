## December 2025
## CooledBeans
## 1.21.11
scoreboard objectives add mp.const dummy
scoreboard objectives add mp.persist dummy
scoreboard objectives add mp.temp dummy
scoreboard objectives add mp.settings trigger
scoreboard players enable @a mp.settings

advancement revoke @a only mp_utils:left_click_interaction
advancement revoke @a only mp_utils:right_click_interaction
