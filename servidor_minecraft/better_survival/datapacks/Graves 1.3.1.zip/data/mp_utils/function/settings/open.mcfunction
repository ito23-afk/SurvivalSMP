## Opens settings menu
$dialog show @s {\
  type: "minecraft:multi_action", title: "Settings", \
  actions: $(settings_list), \
  exit_action: {label: "Close"}\
}
