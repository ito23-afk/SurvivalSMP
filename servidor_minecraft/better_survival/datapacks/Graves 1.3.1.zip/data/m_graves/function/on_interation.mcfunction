## As interaction entity at itself when interacted with
execute if entity @s[tag=multipack.grave] run function m_graves:graves/grave_interaction