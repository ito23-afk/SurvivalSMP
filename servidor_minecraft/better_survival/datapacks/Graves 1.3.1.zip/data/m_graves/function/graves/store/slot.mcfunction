## Stores the slot $(slot)
$execute if score #graves.keep_items mp.settings matches 1 if items entity @s $(slot) #m_graves:kept_items run return run data remove storage multipack:graves $(path)
$execute if data storage multipack:graves $(path) run data modify storage multipack:graves $(path).Slot set value "$(slot)"
$item replace entity @s $(slot) with air
