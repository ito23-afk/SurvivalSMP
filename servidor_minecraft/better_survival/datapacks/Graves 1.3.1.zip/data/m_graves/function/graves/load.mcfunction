## Players leave graves containing their items and xp on death.
scoreboard objectives add mp.death deathCount
scoreboard objectives add mp.graves dummy
scoreboard players reset @a mp.death

scoreboard players set #graves.current_version mp.settings 1030100
execute unless score #graves.version mp.settings matches -2147483648..2147483647 run \
  scoreboard players operation #graves.version mp.settings = #graves.current_version mp.settings
execute unless score #graves.version mp.settings >= #graves.current_version mp.settings run function m_graves:update

execute unless data storage multipack:settings graves run function m_graves:settings/reset
execute unless data storage multipack:settings included_settings[{graves:true}] run \
  data modify storage multipack:settings settings_list append value \
  {label: "Grave Settings", action: {type: "minecraft:run_command",command: "/trigger mp.settings set 10"}}
execute unless data storage multipack:settings included_settings[{graves:true}] run \
  data modify storage multipack:settings included_settings append value {graves:true}

execute if score #graves mp.settings matches 0 if score #graves.disabled_keep_inventory mp.settings matches 0 in overworld run gamerule keep_inventory false
execute if score #graves mp.settings matches 0 if score #graves.disabled_keep_inventory mp.settings matches 0 in the_nether run gamerule keep_inventory false
execute if score #graves mp.settings matches 0 if score #graves.disabled_keep_inventory mp.settings matches 0 in the_end run gamerule keep_inventory false
execute if score #graves mp.settings matches 0 if score #graves.disabled_immediate_respawn mp.settings matches 1 in overworld run gamerule immediate_respawn false
execute if score #graves mp.settings matches 0 if score #graves.disabled_immediate_respawn mp.settings matches 1 in the_nether run gamerule immediate_respawn true
execute if score #graves mp.settings matches 0 if score #graves.disabled_immediate_respawn mp.settings matches 1 in the_end run gamerule immediate_respawn true
execute if score #graves mp.settings matches 0 run schedule clear m_graves:graves/loop_1s

execute unless score #graves mp.settings matches 0 in overworld run gamerule keep_inventory true
execute unless score #graves mp.settings matches 0 in the_nether run gamerule keep_inventory true
execute unless score #graves mp.settings matches 0 in the_end run gamerule keep_inventory true
execute unless score #graves mp.settings matches 0 in overworld run gamerule immediate_respawn false
execute unless score #graves mp.settings matches 0 in the_nether run gamerule immediate_respawn false
execute unless score #graves mp.settings matches 0 in the_end run gamerule immediate_respawn false
execute unless score #graves mp.settings matches 0 run schedule function m_graves:graves/loop_1s 1s append
