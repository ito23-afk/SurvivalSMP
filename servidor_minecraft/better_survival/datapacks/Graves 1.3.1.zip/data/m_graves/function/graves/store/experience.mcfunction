## Store experience in 'multipack:graves' and clears it
execute if score #graves.keep_xp mp.settings matches 1 run return run data modify storage multipack:graves Xp set value 0
xp add @s -1
execute store result storage multipack:graves Xp int 7 run data get entity @s XpLevel
xp set @s 0
xp set @s 0 levels
