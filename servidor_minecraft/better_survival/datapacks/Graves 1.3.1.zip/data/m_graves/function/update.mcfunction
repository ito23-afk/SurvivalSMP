## Updates m_graves
say Updating m_graves to 1.3.1
execute unless data storage multipack:settings graves.auto_equip run data merge storage multipack:settings {graves:{auto_equip:1}}
scoreboard players operation #graves.version mp.settings = #graves.current_version mp.settings