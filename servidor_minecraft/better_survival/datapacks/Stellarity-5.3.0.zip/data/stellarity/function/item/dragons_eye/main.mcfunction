team join stellarity.dragons_eye.pacified @e[type=#stellarity:pacified_by_dragons_eye]
team join stellarity.dragons_eye.pacified @s

tag @s add stellarity.item.dragons_eye.holding

effect clear @s weakness
effect clear @s slowness
effect clear @s nausea
effect clear @s blindness
effect clear @s hunger
effect clear @s mining_fatigue
effect clear @s darkness
