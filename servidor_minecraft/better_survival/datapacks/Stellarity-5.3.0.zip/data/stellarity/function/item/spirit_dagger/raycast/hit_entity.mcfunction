scoreboard players set #hit stellarity.misc 1

execute as @p[scores={stellarity.item.spirit_dagger.consume_time=10}] run function stellarity:item/spirit_dagger/effects/teleport
